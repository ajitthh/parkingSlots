<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('customer', function (Blueprint $table) {
            $table->increments('customer_id');
            $table->string("customer_name","30");
            $table->string("phone_number")->unique();
            $table->binary("driving_licence");
            $table->string("vehicle_number","100");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customer');
    }
};
