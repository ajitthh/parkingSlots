<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Customer;
use App\Models\Parking;
use App\Models\Slots;
use Illuminate\Support\Facades\Validator;
use Log;

class HomeController extends Controller
{
    public function customerList(){
      $customerLists= Customer::leftjoin('parking', 'customer.customer_id', '=', 'parking.customer_id')->where('parking.status', '=', 1)->get(['customer.customer_name', 'parking.parking_fee']);
            return view('customerList')->with("customerLists",$customerLists);
    }
    public function bookParking(Request $request){
        try{
          $validation =  Validator::make($request->all(), [
           'file'   => 'required|mimes:pdf|min:20|max:5000',
          ]);
          if($validation->fails()){
            return $validation->errors();
          }
        $request->file('file')->store("public/uploads/");
        $datas=json_decode($request->data);
        $customerData=Customer::where("phone_number",$datas->phone_number)->first(['phone_number']);
        if(isset($customerData->phone_number)){
          return array("Phone number already exist");
        }
                $create = Customer::create([
                            'customer_name' => $datas->customer_name,
                            'phone_number' => $datas->phone_number,
                            'driving_licence' => $request->file('file'),
                            'vehicle_number' => $datas->vehicle_number
                        ]);
        $lastInsertID = $create->id;
        $slotData=Slots::where("status",false)->first(['slots_id','slot_number','slot_name']);   
        $lastParkingData=Parking::orderBy("parking_id","DESC")->first();
        $i="AAA";
        $appointmentNumber=$i;
        if(isset($lastParkingData->appointment_number) && $lastParkingData->appointment_number){
            $i=substr ($lastParkingData->appointment_number, -3);
            $appointmentNumber=( $i++ != 'ZZZ' )?$i:"";
        }    
        $appointmentNumber=$slotData->slot_number.$appointmentNumber;
        $parkingFee=10;
        $this->addParkingData($appointmentNumber,$slotData->slot_number,$parkingFee,$lastInsertID);
        $this->updateSlotStatus($slotData->slot_number);        
        return array("appointmentNumber"=>$appointmentNumber,"slotNumber"=>$slotData->slot_number,"expectedParkingFee"=>$parkingFee);
      }catch(Exception $e){
        return array("Error"=>$e);
      }
    }
    public function updateSlotStatus($slotNumber){
      $slotData = Slots::where('slot_number',$slotNumber)->where("status",false)->update(['status'=> true]);
    }
    public function addParkingData($appointmentNumber,$slot_number,$parkingFee,$lastInsertID){
        $createParking = Parking::create([
                            'booking_start_date_time' => date('Y-m-d H:i:s' , strtotime(now())),
                            'booking_end_date_time' => date('Y-m-d H:i:s' , strtotime('+3 hours')),
                            'slots' => $slot_number,
                            'appointment_number' => $appointmentNumber,
                            'parking_fee' => $parkingFee,
                            'customer_id' => $lastInsertID,
                            'status'=>false
                        ]);    
    }
    public function checkoutParking(Request $request){
      $validation =  Validator::make($request->all(), [
           'parkingId'   => 'required'
          ]);
          if($validation->fails()){
            return $validation->errors();
          }
        $parkingData = Parking::where("parking_id",$request->parkingId)->first(['booking_start_date_time','booking_end_date_time','slots']);
        $from_time = strtotime($parkingData->booking_start_date_time); 
        $to_time = strtotime(date('Y-m-d H:i:s' , strtotime(now())));
        $current_time=date('Y-m-d H:i:s' , strtotime(now()));
        $diff_hours = round((abs($from_time - $to_time) / 60)/60,2);
        $totalParkingFee=0;
        if($diff_hours <= 3){
          $totalParkingFee=10;
        }
        if($diff_hours > 3){
            $totalParkingFee=10;
            $balanceTime=$diff_hours-3;
            $totalParkingFee=$totalParkingFee+($balanceTime*5);
        }
        if($diff_hours >=24){
            $hourTime=$diff_hours/24;
            $minuteTime=$diff_hours%24;
            $totalParkingFee=$totalParkingFee+(100 * $hourTime);
            if($minuteTime){
                $totalParkingFee=$totalParkingFee+5*$minuteTime;
            }
        }
        $this->updateParkingData($request->parkingId,$totalParkingFee,$current_time);
        $this->removeSlotAllocation($parkingData->slots);
        return array("parkingFee"=>$totalParkingFee);
    }
    public function updateParkingData($parkingId,$totalParkingFee,$current_time){
      $slotData = Parking::where('parking_id',$parkingId)->update(['parking_fee'=> $totalParkingFee,"booking_end_date_time"=>$current_time,"status"=>true]);
    }
    public function removeSlotAllocation($slotNumber){
      $slotData = Slots::where('slot_number',$slotNumber)->update(['status'=> false]);
    }
    public function upcomingList(){
      $customerLists= Customer::leftjoin('parking', 'customer.customer_id', '=', 'parking.customer_id')->where('parking.status', '=', 0)->get(['customer.customer_name', 'parking.parking_fee', 'parking.slots', 'parking.appointment_number', 'parking.booking_start_date_time']);
            return view('upcomingList')->with("customerLists",$customerLists);
    }
}
